#include "game_manager.h"

int main(){
    GameManager TetrisGame;
    TetrisGame.game_loop();
    return 0;
}
